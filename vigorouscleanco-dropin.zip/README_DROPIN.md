# Vigorous Clean Co. — Drop‑in Files (Replace Only)

You said you only want to **replace** or **delete**. Do this exactly:

1) In your repo, **delete** the folders/files below (if they exist):
   - `/app` (entire folder)
   - `/components` (entire folder)

2) **Upload these new ones** from this ZIP (replace with the ones in this folder):
   - `/app` (entire folder)
   - `/components` (entire folder)
   - `tailwind.config.js` (root)
   - `postcss.config.js` (root)
   - `jsconfig.json` (root)

3) **Do NOT delete your `/public` folder.** Keep your files:
   - `logo.png`, `hero-home.jpg`, `og-cover.jpg`, etc.
   - The new code already points to those names.

4) Ensure Tailwind packages are installed:
   ```bash
   npm install -D tailwindcss postcss autoprefixer
   ```

5) Make sure `package.json` has:
   ```json
   {
     "scripts": {
       "dev": "next dev",
       "build": "next build",
       "start": "next start"
     }
   }
   ```

6) Run locally:
   ```bash
   npm run dev
   ```
   Visit http://localhost:3000 — Navbar + hero + sections should appear styled.

7) Deploy to Vercel as usual.

If anything looks unstyled, double‑check that **tailwind.config.js** and **postcss.config.js** are at the **project root**, and that **app/globals.css** contains the three Tailwind directives.
