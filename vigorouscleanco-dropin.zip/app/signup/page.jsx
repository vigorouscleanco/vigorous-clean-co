export const metadata = { title: "Sign up — Vigorous Clean Co." };
export default function SignupPage() { return (
  <div className="container-app py-14">
    <h1 className="text-3xl font-semibold">Create your account</h1>
    <p className="text-gray-600 mt-2">Coming soon.</p>
  </div>
);}
