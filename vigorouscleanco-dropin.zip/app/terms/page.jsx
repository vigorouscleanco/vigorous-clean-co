export const metadata = { title: "Terms — Vigorous Clean Co." };
export default function TermsPage() { return (
  <div className="container-app py-14 prose prose-gray max-w-none">
    <h1>Terms & Conditions</h1>
    <p>By booking with Vigorous Clean Co., you agree to our transparent square-foot pricing and indoor windows policy.</p>
  </div>
);}
