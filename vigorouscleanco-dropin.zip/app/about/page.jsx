export const metadata = { title: "About — Vigorous Clean Co." };

export default function AboutPage() {
  return (
    <div className="container-app py-14">
      <h1 className="text-3xl font-semibold">About Us</h1>
      <p className="text-gray-600 mt-4 max-w-2xl">
        Vigorous Clean Co. is an eco-friendly, pet-safe cleaning service serving Los Angeles and Orange County.
        We price by square footage — not by the hour — so you always know what you’ll pay.
        Our mission is simple: deliver a sparkling space with modern, Apple-/Nike-style simplicity.
      </p>
    </div>
  );
}
