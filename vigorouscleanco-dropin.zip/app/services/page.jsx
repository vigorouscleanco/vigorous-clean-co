export const metadata = { title: "Services — Vigorous Clean Co." };

const services = [
  { title: "Standard Home Clean", items: ["Kitchen & appliances exterior", "Bathrooms & fixtures", "Bedrooms & living areas", "Dusting & surfaces", "Floors (vacuum & mop)", "Indoor windows & mirrors"] },
  { title: "Deep Clean", items: ["Everything in Standard", "Baseboards & trim", "Detail in kitchens/baths", "Inside oven & fridge", "Light fixtures & vents"] },
  { title: "Office Clean", items: ["Desks & common areas", "Bathrooms", "Trash removal", "Breakroom/kitchenette", "Floors", "Indoor windows"] },
];

export default function ServicesPage() {
  return (
    <div className="container-app py-14">
      <h1 className="text-3xl font-semibold">Our Services</h1>
      <p className="text-gray-600 mt-4 max-w-2xl">All add-on services are included in our square-foot pricing. We do <b>indoor</b> windows only.</p>

      <div className="mt-8 grid md:grid-cols-3 gap-6">
        {services.map((s, i) => (
          <div key={i} className="rounded-2xl border border-gray-100 p-6 hover:shadow-soft">
            <h3 className="font-semibold">{s.title}</h3>
            <ul className="mt-3 text-gray-600 list-disc list-inside space-y-1">
              {s.items.map((it, idx) => <li key={idx}>{it}</li>)}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
