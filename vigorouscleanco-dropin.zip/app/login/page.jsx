export const metadata = { title: "Log in — Vigorous Clean Co." };
export default function LoginPage() { return (
  <div className="container-app py-14">
    <h1 className="text-3xl font-semibold">Log in</h1>
    <p className="text-gray-600 mt-2">Coming soon.</p>
  </div>
);}
