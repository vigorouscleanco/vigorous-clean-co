import Link from "next/link";
import Image from "next/image";

export default function HomePage() {
  return (
    <div>
      {/* HERO */}
      <section className="section-gradient">
        <div className="container-app py-16 sm:py-24">
          <div className="grid md:grid-cols-2 gap-10 items-center">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full bg-gray-100 px-3 py-1 text-xs font-medium mb-4">
                <span className="h-2 w-2 rounded-full bg-primary inline-block" /> Eco-Friendly · Pet-Safe · Professional
              </div>
              <h1 className="text-4xl sm:text-5xl font-semibold leading-tight">
                Your Space, <span className="text-primary">Sparkling with Vigor</span>
              </h1>
              <p className="mt-5 text-lg text-gray-600 max-w-xl">
                Book premium home & office cleaning in minutes. Transparent square-foot pricing, no hourly games. Serving Los Angeles & Orange County.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link href="/pricing" className="rounded-2xl bg-primary px-6 py-3 text-white font-medium shadow-soft hover:opacity-90 transition">
                  View Pricing & Book
                </Link>
                <Link href="/services" className="rounded-2xl border border-gray-200 px-6 py-3 font-medium hover:bg-gray-50 transition">
                  Our Services
                </Link>
              </div>
              <p className="mt-4 text-sm text-gray-500">Indoor windows included. Second cleaner required for spaces over 3,500 sq ft.</p>
            </div>
            <div className="relative">
              <div className="rounded-2xl shadow-soft overflow-hidden ring-1 ring-gray-100">
                <Image src="/hero-home.jpg" alt="Vigorous Clean Co. — hero" width={1600} height={1067} className="w-full h-auto" priority />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section>
        <div className="container-app py-16 sm:py-20">
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { title: "Transparent Pricing", desc: "Flat daily rates by square footage — simple, fair, predictable." },
              { title: "Eco & Pet-Friendly", desc: "We use safe, effective products your family and pets will love." },
              { title: "Professionally Trained", desc: "Trusted cleaners with checklists and quality standards." },
            ].map((f, i) => (
              <div key={i} className="rounded-2xl border border-gray-100 p-6 hover:shadow-soft transition">
                <h3 className="font-semibold text-lg">{f.title}</h3>
                <p className="text-gray-600 mt-2">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SERVICES PREVIEW */}
      <section className="bg-grayLight">
        <div className="container-app py-16 sm:py-20">
          <div className="flex items-end justify-between gap-4">
            <h2 className="text-2xl sm:text-3xl font-semibold">Popular Services</h2>
            <Link href="/services" className="text-sm font-medium hover:underline">See all services</Link>
          </div>
          <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { title: "Standard Home Clean", desc: "Kitchen, bathrooms, bedrooms, living areas, indoor windows & surfaces." },
              { title: "Deep Clean", desc: "Baseboards, fixtures, inside appliances, detail work — full refresh." },
              { title: "Office Clean", desc: "Desks, common areas, bathrooms, trash, indoor windows, floors." },
            ].map((s, i) => (
              <div key={i} className="rounded-2xl bg-white border border-gray-100 p-6 hover:shadow-soft">
                <h3 className="font-semibold">{s.title}</h3>
                <p className="text-gray-600 mt-2">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section-gradient">
        <div className="container-app py-16 sm:py-20 text-center">
          <h2 className="text-2xl sm:text-3xl font-semibold">Ready to see that sparkle?</h2>
          <p className="text-gray-600 mt-3 max-w-2xl mx-auto">
            Book a day that works for you. We don’t bill by the hour — we stay until it’s clean.
          </p>
          <div className="mt-6">
            <Link href="/pricing" className="rounded-2xl bg-primary px-8 py-3 text-white font-medium shadow-soft hover:opacity-90 transition">Check Pricing & Book</Link>
          </div>
        </div>
      </section>
    </div>
  );
}
