export const metadata = { title: "Pricing — Vigorous Clean Co." };

const tiers = [
  { range: "0–500 sq ft", day: "$149 / day" },
  { range: "501–1,000 sq ft", day: "$199 / day" },
  { range: "1,001–1,500 sq ft", day: "$249 / day" },
  { range: "1,501–2,000 sq ft", day: "$299 / day" },
  { range: "2,001–2,500 sq ft", day: "$349 / day" },
  { range: "2,501–3,000 sq ft", day: "$399 / day" },
  { range: "3,001–3,500 sq ft", day: "$449 / day" },
  { range: "3,501–4,000 sq ft", day: "$499 / day + second cleaner" },
];

export default function PricingPage() {
  return (
    <div className="container-app py-14">
      <h1 className="text-3xl font-semibold">Simple Square-Foot Pricing</h1>
      <p className="text-gray-600 mt-4 max-w-2xl">
        We charge per <b>day</b>, not per hour. The job’s done when your space is clean — period.
        For spaces above <b>3,500 sq ft</b>, a second cleaner is required (additional fee).
      </p>

      <div className="mt-8 grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tiers.map((t, i) => (
          <div key={i} className="rounded-2xl border border-gray-100 p-6 hover:shadow-soft">
            <h3 className="font-semibold">{t.range}</h3>
            <p className="text-gray-700 mt-2">{t.day}</p>
          </div>
        ))}
      </div>

      <div className="mt-8 rounded-2xl bg-grayLight p-6">
        <h3 className="font-semibold">Recurring Discounts</h3>
        <ul className="text-gray-700 mt-2 list-disc list-inside">
          <li>2 days / month: <b>−5%</b></li>
          <li>4 days / month: <b>−10%</b></li>
          <li>8+ days / month: <b>−15%</b></li>
        </ul>
      </div>

      <div className="mt-8">
        <a href="https://squareup.com/appointments" target="_blank" rel="noopener" className="inline-block rounded-2xl bg-primary px-6 py-3 text-white font-medium shadow-soft hover:opacity-90 transition">
          Book Your Clean (Square)
        </a>
      </div>
    </div>
  );
}
