export const metadata = { title: "FAQ — Vigorous Clean Co." };

const faqs = [
  { q: "Do you bring supplies?", a: "Yes! We bring eco- and pet-friendly products and all basic equipment." },
  { q: "Do you clean outdoor windows?", a: "No. We include indoor windows only." },
  { q: "How do you price?", a: "By square footage per day — no hourly billing. Recurring plans receive discounts." },
  { q: "What areas do you serve?", a: "Greater Los Angeles & Orange County." },
];

export default function FAQPage() {
  return (
    <div className="container-app py-14">
      <h1 className="text-3xl font-semibold">Frequently Asked Questions</h1>
      <div className="mt-8 space-y-4">
        {faqs.map((f, i) => (
          <details key={i} className="rounded-2xl border border-gray-100 p-4">
            <summary className="font-medium cursor-pointer">{f.q}</summary>
            <p className="text-gray-600 mt-2">{f.a}</p>
          </details>
        ))}
      </div>
    </div>
  );
}
