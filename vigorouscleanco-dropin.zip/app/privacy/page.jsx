export const metadata = { title: "Privacy — Vigorous Clean Co." };
export default function PrivacyPage() { return (
  <div className="container-app py-14 prose prose-gray max-w-none">
    <h1>Privacy Policy</h1>
    <p>We respect your privacy. We only collect what we need to schedule and deliver your cleaning services.</p>
  </div>
);}
