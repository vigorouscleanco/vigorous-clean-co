export default function ContactCompact() {
  return (
    <div className="rounded-2xl border border-gray-100 p-6">
      <h3 className="font-semibold">Questions?</h3>
      <p className="text-gray-600 mt-2 text-sm">Email us and we’ll get back to you ASAP.</p>
      <a href="mailto:hello@vigorouscleanco.com" className="mt-4 inline-block rounded-2xl bg-primary px-4 py-2 text-white text-sm font-medium">
        Email Us
      </a>
    </div>
  );
}
